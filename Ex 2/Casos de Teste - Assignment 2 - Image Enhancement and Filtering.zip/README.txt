Arquivo zip gerado em: 20/04/2022 10:59:04 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Assignment 2 - Image Enhancement and Filtering